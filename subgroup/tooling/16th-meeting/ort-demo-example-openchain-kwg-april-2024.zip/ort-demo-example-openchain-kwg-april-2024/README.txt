OSS Review Toolkit Example 

This directory contains an ORT scan of version 2.1.26 of the Mime Types project (https://github.com/jshttp/mime-types)
and was created to give a taste of how ORT works.

If you like some help on getting ORT set up in your organization or have questions please contact  Thomas Steenbergen (opensource@steenbe.nl)


OSS 검토 툴킷 예

이 디렉터리에는 Mime Types 프로젝트(https://github.com/jshttp/mime-types) 버전 2.1.26의 ORT 스캔이 포함되어 있습니다.
ORT가 어떻게 작동하는지 맛보기 위해 만들어졌습니다.

조직에 ORT를 설정하는 데 도움이 필요하거나 질문이 있는 경우 Thomas Steenbergen(opensource@steenbe.nl)에게 문의하세요.